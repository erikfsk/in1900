You must have Arduino installed.
And have a 4.7KOhm resistor and a DS18B20 temp sensor(see ds18b20-waterproof.jpg).

1. Open zip files
2. Move all the .h files to your arduino libraries folder
3. Make the circuit displayed (arduino_ds18b20_connection.jpg)
4. Compile and upload the ino file to your arduino
