# -*- coding: utf-8 -*-
from heat_equation_ui import *
import matplotlib.pyplot as plt
import cPickle as pickle
from matplotlib import cm
from numpy import *
from instant import inline_with_numpy
import timeit

"""
Follow logging.info() 
it tells you what is happening in the next lines of code
it is straight forward.
"""

logging.info("setting variabels...")
steps = int((t1-t0)/dt)


logging.info("setting matrixs...")
u = zeros((m,n)); u_new = zeros((m,n))

#input
if args.input:
	logging.info("reading to infile...")
	infile = open(input_file,"rb")
	u = pickle.load(infile)
	infile.close()


logging.info("making c...")
c_code = """
void step (int x1, int y1, double* u, int x2, int y2, double* u_new,double dt,double nu,double f){
	for (int i = 1; i<x1-1; i++){
		for (int j = 1; j<y1 -1; j++){
			u_new[i*y1 + j] = u[i*y1 + j] + dt*(nu*u[(i-1)*y1 + j] + nu*u[i*y1 + j-1] - 4*nu*u[i*y1 + j] + nu*u[i*y1 + j+1] + nu*u[(i+1)*y1 + j] + f);
		}

		for (int j = 1; j<y1 -1; j++){
			u[i*y1 + j] = u_new[i*y1 + j] + 0;
		}
	}
}
"""

step = inline_with_numpy(c_code, arrays = [['x1', 'y1', 'u'],
                                               ['x2', 'y2', 'u_new']],
                             cache_dir="test_ex2_cache")

#solving equation
logging.info("solving equation...")
for i in xrange(steps):
	step(u,u_new,dt,nu,f)

#output
if args.output:
	logging.info("writing to outfile...")
	outfile = open(output_file, "w")
	pickle.dump(u,outfile)
	outfile.close()

#plot
logging.info("ploting...")
plt.subplot(1,2,1)     
plt.imshow(zeros((m,n)), interpolation='nearest', cmap=cm.gray)
plt.subplot(1,2,2)
plt.imshow(u, interpolation='nearest', cmap=cm.gray)
plt.colorbar()
plt.show()

def step_time():
	step(u,u_new,dt,nu,f)

if args.timeit:
	logging.info("time it...")
	timer = timeit.Timer(stmt="step_time()", setup="from __main__ import step_time")
	times = timer.repeat(repeat=100, number=10)
	print "Tested 10 steps 100 times, best time for 10 steps was %e secs" % min(times)