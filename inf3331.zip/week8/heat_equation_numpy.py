# -*- coding: utf-8 -*-
from heat_equation_ui import *
import matplotlib.pyplot as plt
import cPickle as pickle
from matplotlib import cm
from numpy import *
import timeit

"""
Follow logging.info() 
it tells you what is happening in the next lines of code
it is straight forward.
"""

logging.info("setting variabels...")
steps = int((t1-t0)/dt)

logging.info("setting matrixs...")
u = zeros((m,n)); u_new = zeros((m,n))


#input
if args.input:
	logging.info("reading to infile...")
	infile = open(input_file,"rb")
	u = pickle.load(infile)
	infile.close()

def step():
	u_new[1:-1,1:-1] = u[1:-1,1:-1] + dt*(nu*u[:-2,1:-1] + nu*u[1:-1,:-2] - 4*nu*u[1:-1,1:-1] + nu*u[1:-1,2:] + nu*u[2:,1:-1] + f)
	u[1:,1:] = u_new[1:,1:]

#solving equation
logging.info("solving equation...")
for k in xrange(steps):
	step()


#output
if args.output:
	logging.info("writing to outfile...")
	outfile = open(output_file, "w")
	pickle.dump(u,outfile)
	outfile.close()

#plot
logging.info("ploting...")
plt.subplot(1,2,1)     
plt.imshow(zeros((m,n)), interpolation='nearest', cmap=cm.gray)
plt.subplot(1,2,2)
plt.imshow(u_new, interpolation='nearest', cmap=cm.gray)
plt.colorbar()
if args.savefig:
	logging.info("saving fig...")
	plt.savefig("figure.png")
plt.show()

if args.timeit:
	logging.info("time it...")
	timer = timeit.Timer(stmt="step()", setup="from __main__ import step")
	times = timer.repeat(repeat=100, number=10)
	print "Tested 10 steps 100 times, best time for 10 steps was %e secs" % min(times)