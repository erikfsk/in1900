
import os
from distutils.core import setup, Extension
name = 'instant_module_ba13e738102665dab9b3c6febdf0f1cbc298b649'
swig_cmd =r'swig -python  -I/Users/Erik/Library/Python/2.7/lib/python/site-packages/instant/swig -c++ -fcompact -O -I. -small instant_module_ba13e738102665dab9b3c6febdf0f1cbc298b649.i'
os.system(swig_cmd)
sources = ['instant_module_ba13e738102665dab9b3c6febdf0f1cbc298b649_wrap.cxx']
setup(name = 'instant_module_ba13e738102665dab9b3c6febdf0f1cbc298b649',
      ext_modules = [Extension('_' + 'instant_module_ba13e738102665dab9b3c6febdf0f1cbc298b649',
                     sources,
                     include_dirs=['/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/site-packages/numpy/core/include'],
                     library_dirs=[],
                     libraries=[] , extra_compile_args=['-O2'] )])
