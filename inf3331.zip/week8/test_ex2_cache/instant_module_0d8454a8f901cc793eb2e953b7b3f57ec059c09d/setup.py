
import os
from distutils.core import setup, Extension
name = 'instant_module_0d8454a8f901cc793eb2e953b7b3f57ec059c09d'
swig_cmd =r'swig -python  -I/Users/Erik/Library/Python/2.7/lib/python/site-packages/instant/swig -c++ -fcompact -O -I. -small instant_module_0d8454a8f901cc793eb2e953b7b3f57ec059c09d.i'
os.system(swig_cmd)
sources = ['instant_module_0d8454a8f901cc793eb2e953b7b3f57ec059c09d_wrap.cxx']
setup(name = 'instant_module_0d8454a8f901cc793eb2e953b7b3f57ec059c09d',
      ext_modules = [Extension('_' + 'instant_module_0d8454a8f901cc793eb2e953b7b3f57ec059c09d',
                     sources,
                     include_dirs=['/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/site-packages/numpy/core/include'],
                     library_dirs=[],
                     libraries=[] , extra_compile_args=['-O2'] )])
