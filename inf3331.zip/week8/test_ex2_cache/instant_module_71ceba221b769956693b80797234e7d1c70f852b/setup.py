
import os
from distutils.core import setup, Extension
name = 'instant_module_71ceba221b769956693b80797234e7d1c70f852b'
swig_cmd =r'swig -python  -I/Users/Erik/Library/Python/2.7/lib/python/site-packages/instant/swig -c++ -fcompact -O -I. -small instant_module_71ceba221b769956693b80797234e7d1c70f852b.i'
os.system(swig_cmd)
sources = ['instant_module_71ceba221b769956693b80797234e7d1c70f852b_wrap.cxx']
setup(name = 'instant_module_71ceba221b769956693b80797234e7d1c70f852b',
      ext_modules = [Extension('_' + 'instant_module_71ceba221b769956693b80797234e7d1c70f852b',
                     sources,
                     include_dirs=['/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/site-packages/numpy/core/include'],
                     library_dirs=[],
                     libraries=[] , extra_compile_args=['-O2'] )])
