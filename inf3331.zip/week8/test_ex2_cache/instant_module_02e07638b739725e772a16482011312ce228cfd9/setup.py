
import os
from distutils.core import setup, Extension
name = 'instant_module_02e07638b739725e772a16482011312ce228cfd9'
swig_cmd =r'swig -python  -I/Users/Erik/Library/Python/2.7/lib/python/site-packages/instant/swig -c++ -fcompact -O -I. -small instant_module_02e07638b739725e772a16482011312ce228cfd9.i'
os.system(swig_cmd)
sources = ['instant_module_02e07638b739725e772a16482011312ce228cfd9_wrap.cxx']
setup(name = 'instant_module_02e07638b739725e772a16482011312ce228cfd9',
      ext_modules = [Extension('_' + 'instant_module_02e07638b739725e772a16482011312ce228cfd9',
                     sources,
                     include_dirs=['/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/site-packages/numpy/core/include'],
                     library_dirs=[],
                     libraries=[] , extra_compile_args=['-O2'] )])
