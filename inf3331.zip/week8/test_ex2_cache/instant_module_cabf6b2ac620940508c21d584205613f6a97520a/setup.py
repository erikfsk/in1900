
import os
from distutils.core import setup, Extension
name = 'instant_module_cabf6b2ac620940508c21d584205613f6a97520a'
swig_cmd =r'swig -python  -I/Users/Erik/Library/Python/2.7/lib/python/site-packages/instant/swig -c++ -fcompact -O -I. -small instant_module_cabf6b2ac620940508c21d584205613f6a97520a.i'
os.system(swig_cmd)
sources = ['instant_module_cabf6b2ac620940508c21d584205613f6a97520a_wrap.cxx']
setup(name = 'instant_module_cabf6b2ac620940508c21d584205613f6a97520a',
      ext_modules = [Extension('_' + 'instant_module_cabf6b2ac620940508c21d584205613f6a97520a',
                     sources,
                     include_dirs=['/Library/Frameworks/Python.framework/Versions/2.7/lib/python2.7/site-packages/numpy/core/include'],
                     library_dirs=[],
                     libraries=[] , extra_compile_args=['-O2'] )])
