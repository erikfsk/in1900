# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
from matplotlib import cm
from numpy import *


#variabels
t0 = 0; t1 = 1000; dt = 0.1
steps = int((t1-t0)/dt)

n = 50; m = 100; nu = 1.0

u = zeros((m,n)); f = ones((m,n)); u_new = zeros((m,n)); analytic_u = ones((m,n));


#filling in f and analytic solution
for i in xrange(0,m,1):
	for j in xrange(0,n,1):
		f[i][j] = nu*((2*pi/n)**2 + (2*pi/m)**2)*sin(2*pi/m*i)*sin(2*pi/n*j)
		analytic_u[i][j] = sin(2*pi/m*i)*sin(2*pi/n*j)

#solving equation
for k in xrange(steps):
	u_new[1:-1,1:-1] = u[1:-1,1:-1] + dt*(nu*u[:-2,1:-1] + nu*u[1:-1,:-2] - 4*nu*u[1:-1,1:-1] + nu*u[1:-1,2:] + nu*u[2:,1:-1] + f[1:-1,1:-1])
	u[1:,1:] = u_new[1:,1:]


print (abs(u - analytic_u)).max() #error should be lower then 0.15


#option if you want to see the plot
plt.subplot(1,2,1)     
plt.imshow(u, interpolation='nearest', cmap=cm.gray)
plt.subplot(1,2,2)
plt.imshow(analytic_u, interpolation='nearest', cmap=cm.gray)
plt.colorbar()
plt.show()


