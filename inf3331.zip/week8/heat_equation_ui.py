import argparse
import logging
import os
"""
If u call this program it will only take the arguments and then run one of the other programs.
The setup that you see here is imported too all the other programs so you can run them with -a for example.
If this program is imported it will run the if not main part where variabels and other stuff is set.
if you run the instant version you can not ask the ui to run the python version. if you want to choose version,
you would have to run this program.
The code is straight forward.
"""
input_file = None
output_file = None
arguments_if_this_program_calls_another = ""
parser = argparse.ArgumentParser(
    description='UI for heat equation'
)

#parameters dimensions
parser.add_argument("-a", "--arguments", help="set values for parameters",
                    action="store_true")
#name of output file
parser.add_argument("-o", "--output", help="set an output file for final temp",
                    action="store_true")
#name of input file
parser.add_argument("-i", "--input", help="set an input file for first temp",
                    action="store_true")
#option to save fig
parser.add_argument("-s", "--savefig", help="to save final temp figure",
                    action="store_true")
#switch between python/numpy/C
if __name__ == '__main__':
    parser.add_argument("-p", "--python", help="to run the python version(This will take time)",
                        action="store_true")

    parser.add_argument("-n", "--numpy", help="to run the numpy version",
    					action="store_true")

    parser.add_argument("-c", "--C", help="to run the C version",
    					action="store_true")
#activate verbose
parser.add_argument("-v", "--verbose", help="increase output verbosity",
                    action="store_true")
#timeit module
parser.add_argument("-t", "--timeit", help="use timeit module",
                    action="store_true")
#help message

args = parser.parse_args()



if __name__ != '__main__':
    if args.verbose:
        logging.basicConfig(level=logging.INFO)

    if args.arguments:
        print """
        default values
        t0 = 0; t1 = 1000; dt = 0.1
        n = 50; m = 100
        nu = 1.0; f = 1
        """
        logging.info("setting parameters...")
        t0 = input("t0 = ")
        t1 = input("t1 = ")
        dt = input("dt = ")
        nu = input("nu = ")
        f = input("f = ")
        n = input("n = ")
        m = input("m = ")
    else:
        t0 = 0; t1 = 1000; dt = 0.1
        n = 50
        m = 100
        nu = 1.0
        f = 1;

    if args.input:
        input_file = raw_input("write input file: ")

    if args.output:
        output_file = raw_input("write output file: ")




if __name__ == '__main__':

    if args.verbose:
        arguments_if_this_program_calls_another = arguments_if_this_program_calls_another + " --verbose"

    if args.arguments:
        arguments_if_this_program_calls_another = arguments_if_this_program_calls_another + " --arguments"

    if args.input:
        arguments_if_this_program_calls_another = arguments_if_this_program_calls_another + " --input"

    if args.output:
        arguments_if_this_program_calls_another = arguments_if_this_program_calls_another + " --output"

    if args.savefig:
        arguments_if_this_program_calls_another = arguments_if_this_program_calls_another + " --savefig"

    if args.timeit:
        arguments_if_this_program_calls_another = arguments_if_this_program_calls_another + " --timeit"

    if args.numpy:
        os.system("python heat_equation_numpy.py %s" % arguments_if_this_program_calls_another)

    if args.python:
        os.system("python heat_equation.py %s" % arguments_if_this_program_calls_another)

    if args.C:
        os.system("python heat_equation_instant.py %s" % arguments_if_this_program_calls_another)
