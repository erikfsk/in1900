# -*- coding: utf-8 -*-
import matplotlib.pyplot as plt
from matplotlib import cm
from heat_equation_ui import *
import cPickle as pickle
import timeit
"""
Follow logging.info() 
it tells you what is happening in the next lines of code
it is straight forward.
"""
logging.info("setting variabels...")
steps = int((t1-t0)/dt)



logging.info("setting matrixs...")
u = []; u_new = []

for i in range(m):
	u.append([0] * n)
	u_new.append([0] * n)


#input
if args.input:
	logging.info("reading to infile...")
	infile = open(input_file,"rb")
	u = pickle.load(infile)
	infile.close()



plt.subplot(1,2,1)     
plt.imshow(u, interpolation='nearest', cmap=cm.gray)

def step():
	for i in range(1,m-1,1):
		for j in range(1,n-1,1):
			u_new[i][j] = u[i][j] + dt*(nu*u[i-1][j] + nu*u[i][j-1] - 4*nu*u[i][j] + nu*u[i][j+1] + nu*u[i+1][j] + f)

		for j in range(1,n-1,1):
			u[i][j] = u_new[i][j] + 0

logging.info("solving equation...")
for k in range(steps):
	step()

#output
if args.output:
	logging.info("writing to outfile...")
	outfile = open(output_file, "w")
	pickle.dump(u,outfile)
	outfile.close()


#plot
logging.info("ploting...")
plt.subplot(1,2,2)
plt.imshow(u_new, interpolation='nearest', cmap=cm.gray)
plt.colorbar()
if args.savefig:
	logging.info("saving fig...")
	plt.savefig("figure.png")
plt.show()

if args.timeit:
	logging.info("time it...")
	timer = timeit.Timer(stmt="step()", setup="from __main__ import step")
	times = timer.repeat(repeat=100, number=10)
	print "Tested 10 steps 100 times, best time for 10 steps was %e secs" % min(times)