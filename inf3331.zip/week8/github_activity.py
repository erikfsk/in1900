import matplotlib.pyplot as plt
import numpy as np
from subprocess import *
import argparse
import os
import re
import time
from dateutil import rrule
from datetime import *

#default dir
gitDir = "/Users/Erik/INF3331-ErikFageraas/"
#default savefigname
savefigname = "GitActivity.pdf"

parser = argparse.ArgumentParser(
    description='Github activity'
)

parser.add_argument("-d", "--dir", help="set a dir (if not called /Users/Erik/INF3331-ErikFageraas/ is default)",
                    action="store_true")

parser.add_argument("-s", "--save", help="option to save fig to a user specfic file",
                    action="store_true")

args = parser.parse_args()



# if dir is called ask for dir and see if it is actually a git dir
if args.dir:
	gitDir = raw_input("Provide git dir:\n")

	print "\nchecking if it is a git dir\n"
	Git_DIR = os.system("""
		cd
		cd %s
		git rev-parse --git-dir""" % gitDir)
	print ""
	if (Git_DIR != 0):
		print "%s is not a valid git dir\nEXIT..." % gitDir
		exit()
	else:
		print "%s is a git dir\nCONTINUE... " % gitDir


# is save is pasted as arg, ask for a savefile
if args.save:
	savefigname = raw_input("save file as (write format): ")

def author_commits(gitdir):
	"""
	gets the git log from the terminal
	uses regex to extract all the dates
	and authors
	"""
	p = Popen('cd\ncd %s\ngit log --all' % gitdir, shell=True, stdout=PIPE)
	(log, _) = p.communicate() # use popen to extract git log

	#extract authors and dates
	authors = re.findall("Author: (.*?) <.*",log,re.IGNORECASE)
	datoer = re.findall("Date:   .{3} (.*?) (.*?) .{2}:.{2}:.{2} (.*) .{5}",log,re.IGNORECASE)

	formater_dato = []
	for i in range(len(datoer)):
		formater_dato.append([datoer[i][0],int(datoer[i][1]),int(datoer[i][2])])

	dic_month = {"Jan" : 1,"Feb" : 2,"Mar" : 3,"Apr" : 4,"May" : 5,"Jun" : 6,"Jul" : 7,"Aug" : 8,"Sep" : 9,"Oct" : 10,"Nov" : 11,"Dec" : 12}

	#format dates so they can be used.
	for i in range(len(formater_dato)):
		formater_dato[i][0] = dic_month[formater_dato[i][0]]

	return authors, formater_dato 

def number_of_authors(authors):
	"""
	returns a dict with all the authors as keyword and a value in it place
	"""
	list_authors = {}
	counter = 0
	for i in authors:
		if i not in list_authors:
			list_authors[i] = counter
			counter = counter + 1
	return list_authors

def ready_to_plot(gitDir):
	"""
	returns everything you need to plot.
	the names explain it:
	return np.array(number_of_entries), dict_of_diff_authors, nr_of_days
	"""
	authors, commits = author_commits(gitDir)
	dict_of_diff_authors = number_of_authors(authors)
	number_of_entries = []
	first_commit = commits[-1]
	now = datetime.now()
	first = datetime(first_commit[2],first_commit[0],first_commit[1])

	nr_of_days = 0

	for dt in rrule.rrule(rrule.DAILY, dtstart=first, until=now): # loop over the days
		commits_today = [0]*len(dict_of_diff_authors)
		for i in range(len(commits)):
			if (dt.day == commits[i][1]) and (dt.month == commits[i][0]) and (dt.year == commits[i][2]):
				commits_today[dict_of_diff_authors[authors[i]]] += 1 
		number_of_entries.append(commits_today)
		nr_of_days += 1
	
	return np.array(number_of_entries), dict_of_diff_authors, nr_of_days




number_of_entries ,dict_of_diff_authors, nr_of_days  = ready_to_plot(gitDir)
color_dict = {0 : 'b',1 : 'g',2 : 'r',3 : 'c',4 : 'm',5 : 'y',6 : 'k',7 : 'w'} # can max show 8 different people

ind = np.arange(nr_of_days)  # the x locations for the groups
width = 1       # the width of the bars

fig, ax = plt.subplots()


for i in range(len(dict_of_diff_authors)):
	ax.bar(ind, number_of_entries[:,i], width, color=color_dict[i])
	
# add some text for labels, title and axes ticks
ax.set_ylabel('Commits')
ax.set_xlabel('Days since first commit')
ax.set_title('Commits over time to the git dir %s' % gitDir)

#setting legend for all the users that have commited
list_legend = []
for args in dict_of_diff_authors:
	list_legend.append(args)

ax.legend(list_legend)
ax.axis([0, nr_of_days,0,number_of_entries.max()+1])
plt.savefig(savefigname)
plt.show()







