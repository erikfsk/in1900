#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
from StringIO import StringIO
import os

namespace = vars().copy()

def feedline(string):
	"""
	Give feedline a string which is code and feedline will try to execute or eval it.

	Args:
		string 		#a string to exec(string) or eval(string)
	Returns:
		out 		#a string containing the output that 'string' produced
	Raises:

	Example usage:
	>>> feedline("print 1")
	1
	>>> feedline("x = 1")

	>>> feedline(print x)
	1
	"""
	# Swap stdout with a StringIO instance
	oldout, sys.stdout = sys.stdout, StringIO()
	if len(string) > 0 and string[0] == '!': #cmd 
		os.system(string[1:])
		out = sys.stdout.getvalue()
	elif len(string) > 0 and string[-1] == '?': #help cmd
		try:
			print help(eval(string[:-1],namespace))
			out = sys.stdout.getvalue()
		except Exception as e:
			out = "{}\n".format(e)

	else: # else normal python code
		try:
			print eval(string,namespace)
			out = sys.stdout.getvalue()
		except SyntaxError:
			try:
				exec(string, namespace)
				out = sys.stdout.getvalue()
			except Exception as e:
				out = "{}\n".format(e)
		except Exception as e:
			out = out = "{}\n".format(e)

	# Reset stdout
	sys.stdout = oldout
	# Print out captured stdout
	return out

if __name__ == '__main__':
	#tests from the assignment
	print feedline('print "hello world"')
	print feedline("")
	print feedline("x = 1")
	print feedline("x += 1")
	print repr(feedline("print x"))
	print feedline("from math import sin")
	print feedline("def f(x):	return sin(x**2)")
	print feedline("f(x)")