#!/usr/bin/env python
# -*- coding: utf-8 -*-

from feedline import feedline
from getchar import getchar
import os
import sys as sys

def prompt():
	"""Starts myPython a iPython clone
	Args:
		-
	Returns:
		-
	Functions:
		clear_line() #Used to clear a line the terminal

	Example usage:
	>>> prompt()
	>>> #write your code
	#your code executed will show up here
	>>> #write your code
	#your code executed will show up here
	...
	...
	...
	# and it contiunes untill you type exit() or use CTRL+D
	"""

	def clear_line(line):
		"""
		It is meant to be used to clear the current line in the terminal.
		It is called when the users presses on of the following keys (backwards,up or down)
		Args:
			line # A string
		Returns:
			-

		Example usage:
		if the progrem calls clear_line("test")

		Terminal before clear_line, looks like:
		>>>test

		Terminal after clear_line, looks like:
		>>>

		"""
		lengde = len(line)
		sys.stdout.write("\r"+(" "*(lengde+7))+"\r>>>")


	inputs = []		#Buffer
	counter = 0
	current_place_in_inputs = counter

	print "Welcome to myPython!"
	while(True):
		sys.stdout.write(">>>")
		line = ""
		while True:

			char = getchar()
			if '\xc3' in char:
				char = char + getchar()

			# CTRL+D to clear and or exit
			if char == '\x04' and len(line) > 0:
				clear_line(line)
				line = ""

			elif char == '\x04':
				print
				exit()

			elif char == '\x7f': # deletes the last char
				line = line[0:-1]
				sys.stdout.write("\r>>>"+line+" ")
				sys.stdout.write("\r>>>"+line)

			elif char in "\r\n":
				sys.stdout.write("\n")
				break

			elif '\x1b' in char: #UP and down arrow
				char = getchar()
				char = getchar()

				if char == 'A': # up arrow
					if counter == 0:
						pass
					elif current_place_in_inputs == 0: # top of buffer
						line = inputs[current_place_in_inputs]
						sys.stdout.write("\r>>>"+line)
					else:
						current_place_in_inputs -= 1 # somewhere else
						clear_line(line)
						line = inputs[current_place_in_inputs]
						sys.stdout.write("\r>>>"+line)

				elif char == 'B': # down arrow
					if current_place_in_inputs == counter: 		# bot of buffer
						clear_line(line)
						line = ""
						sys.stdout.write("\r>>>"+line)
					elif current_place_in_inputs == counter-1:	# right before bot
						clear_line(line)
						current_place_in_inputs = counter
						line = ""
						sys.stdout.write("\r>>>"+line)
					else: 										#somwhere else
						clear_line(line)
						current_place_in_inputs += 1
						line = inputs[current_place_in_inputs]
						clear_line(line)
						sys.stdout.write("\r>>>"+line)

				elif char == 'C' or char == 'D': # sideArrows
					pass

			else:# add char to line
				sys.stdout.write(char)
				line += char

		inputs.append(line)
		counter += 1
		current_place_in_inputs = counter
		if "%save" in line: # save output file
			outfile = open(line[6:],"w") # open file with given name
			for line in inputs:
				outfile.write(line+"\n")
			outfile.close()
		else:
			sys.stdout.write(feedline(line)) # else feedline and write out the answer



if __name__ == '__main__':
	prompt()
