from subprocess import Popen, PIPE

def test_wordcounter():
    output = Popen(["python", "wordcounter.py", "file_1.txt", "file_2.txt", "file_3.txt"], stdout=PIPE).communicate()[0]
    output = output.split("\n")

    found_file1 = False
    found_file2 = False
    found_file3 = False

    for line in output:
        if "file_1.txt" in line:
            found_file1 = True
            assert "50" in line

        if "file_2.txt" in line:
            found_file2 = True
            assert "100" in line

        if "file_3.txt" in line:
            found_file3 = True
            assert "146" in line

    assert found_file1
    assert found_file2
    assert found_file3
