#!/usr/bin/python

def main():
	import sys

	f = float(sys.argv[1]); c = ( (5./9.)*(f-32))

	print "%.1f fahrenheit is equal to %.1f Celsius." % (f,c)

if __name__ == '__main__':
	main()