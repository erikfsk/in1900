from subprocess import Popen, PIPE

def test_printrandom():
    # Note: We need to fix the random seed to make results predicatble
    output = Popen(["timeout", "1", "python", "-c", "import random; random.seed(1); import printrandom"], stdout=PIPE).communicate()[0]
    output = output.strip().split("\n")
    assert "-0.7313" in  output[0]
    assert "0.6949" in  output[1]
    assert "0.5275" in  output[2]
