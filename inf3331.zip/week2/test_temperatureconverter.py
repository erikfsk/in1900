from subprocess import Popen, PIPE

def test_temperatureconverter():
    output = Popen(["python", "temperatureconverter.py", "10.0"], stdout=PIPE).communicate()[0]
    assert "10.0 fahrenheit" in output.lower()
    assert "-12.2 celsius" in output.lower()
