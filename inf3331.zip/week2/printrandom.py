#!/usr/bin/python

def main():

	import random

	print "%.4f" % (random.uniform(-1,1))

if __name__ == '__main__':
	main()