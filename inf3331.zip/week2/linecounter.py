#!/usr/bin/python

def main():
	import sys

	for i in range(len(sys.argv)-1):
		infile = open(sys.argv[i+1],"r")
		counter = 0

		for line in infile:
			counter += 1

		print sys.argv[i+1]," : ",counter


if __name__ == '__main__':
	main()