# -*- coding: utf-8 -*-
from weatherBuffer import *
import os

def test_dummy_function(x): # dette er en test function til weatherBuffer.py
	"""
	calculate 2*argument
	used for a buffer test
	"""
	print "calc"
	return 2*x

if __name__ == '__main__':
	test = weatherBuffer(test_dummy_function)
	print test(2) 	# output skal v're "calc \n 4"
	print test(2) 	# output skal kun v're "4". 
					#I test_weather_buffer slettes buffer.txt filen slik at outputen er slik hver gang