(: Velkommen :)

veldig fort forklart:

buffer_return_HTML_content_func
 	er bufferen til online retrieval

test_return_HTML_content
 	er en fil til test funksjon av return_HTML_content

testAvDummy.py
 	er et script som blir brukt i test av buffer

testestest.py og testre.py
 	er bare tull... test kode...

warmest_and_coldest.py 
	gir et sted som har det varmeste og et sted som har den kaldeste tempen.
	altså hvis Bergen og Oslo begge er 13 grader (hvis det hadde vært varmest), så
	vil bare en av de returneres... kunne skiftet på det slik at begge ble returnert, men ser 
	ikke et poeng i det. (som kan bli en god ordvits hvis dere trekker meg et poeng for det)

weather.py 
	er bare et script som viser kall på funksjoner. 

weatherBuffer.py
	er bufferen selv. selv der hvordan den ser ut og funker.

weatherFunc.py
	er alle functionene jeg har laget

weatherFuncTests.py 
	er testene til de tingene vi skulle teste.