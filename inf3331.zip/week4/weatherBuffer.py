
import urllib2
import time
import re



class weatherBuffer(object):
	"""
	Meant as a buffer for return_html_content
	description below:
	"""
	def __init__(self, function, time_stamp = None):
		"""
		when u creat the class it will see if u already have a buffer file.
		if yes it will see if it is from today and not more then 6 hours since.
		if thats correct it will use the buffer.
		else it will creat a new buffer
		"""
		self.function = function 	
		self.buffer = {}			
		self.strFunction = (re.findall("\<function (.*) at.*\>",str(function),re.IGNORECASE))[0]
		try:	#we try because this might be the first time i buffer anything for this function
			infile = open("buffer_%s.txt" % self.strFunction,"r")	
			date = (infile.readline()).strip() 						# read date
			tid = int((infile.readline()).strip())					# time
			content_of_file = infile.read()
			if (date == time.strftime("%x")):						#if date equals todays date
				if (time_stamp != None):							#if time stamp, now is time stamp
					now = time_stamp								#
				else:												#else now is the actual now
					now = time.strftime("%H")						#
				if (int(now)-tid) < 6:								 
					args = (re.findall("@@@(.*?)@@@",content_of_file,re.IGNORECASE)) # dette er argumentene
					results = (re.findall("###(.*?)###",content_of_file,re.DOTALL)) # dette er resultatene	
					for i in range(len(args)): 										# save em
						self.buffer[args[i]] = results[i]
				else:
					infile.close()
					raise # if time dif is invalid go to except
			else:
				infile.close()
				raise # if date is invalid go to except
			infile.close()

		except:
			date = time.strftime("%x") 
			if (time_stamp != None):
				tid = time_stamp
			else:
				tid = time.strftime("%H") 

		self.outfile = open("buffer_%s.txt" % self.strFunction,"w") # write out buffer to file
		self.outfile.write(date+"\n") 						# date
		self.outfile.write(str(tid)+"\n") 					# time
		for arg in self.buffer: 							# write out all info in buffer
			self.outfile.write("@@@"+arg+"@@@\n")
			self.outfile.write("###"+self.buffer[arg]+"###"+"\n")
		self.outfile.close()

	def __call__(self, arg):
		"""
		when called it will evaluate if it is a unique arg.
		if not it uses buffer, else it will calc the answer and buffer it
		for later
		"""
		self.outfile = open("buffer_%s.txt" % self.strFunction,"a") 
		if str(arg) in self.buffer:
			return self.buffer[str(arg)] 
		retval = self.function(arg)
		self.buffer[str(arg)] = retval
		self.outfile.write("@@@"+str(arg)+"@@@\n")
		if (type(retval) == list or type(retval) == tuple):
			print "yes"
		else:
			self.outfile.write("###"+(str(retval))+"###"+"\n")
		return retval 
