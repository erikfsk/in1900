# -*- coding: utf-8 -*-
import re
from weatherFunc import *

"""
This is the program that finds the warmest place and the coldest.
The program should use less then a min to do its tasks
"""

warmest_coldest_list = weather_update("",13,00) # should have arguments: "" (matches everything),13 and 00 (at what time)
warmest_coldest_list.pop(0) # pop element 0 because this is the date and time... dont need it
warmest_place = None 
warmest_temp = -50 		# our test functions say that temp should be between -50 and 50 
coldest_place = None
coldest_temp = 50		# thats why i picked these values. i could have picked -1000 and 1000


for i in warmest_coldest_list:
	"""
	check for every elements, if the temp for that place is warmer og colder then the warmest or coldest place 
	set it if it is.
	"""
	liste = (re.findall("(.*?) :.*temp: (.{0,3})  deg C",i,re.IGNORECASE))
	if (float(liste[0][1]) < coldest_temp):
		coldest_temp = float(liste[0][1])
		coldest_place = liste[0][0]

	if (float(liste[0][1]) > warmest_temp):
		warmest_temp = float(liste[0][1])
		warmest_place = liste[0][0]


print "The warmest place is -",warmest_place,"- with a temperature of -",warmest_temp, "- deg C"
print "The coldest place is -",coldest_place,"- with a temperature of -",coldest_temp, "- deg C" # print result


