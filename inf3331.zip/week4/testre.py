# -*- coding: utf-8 -*-
import datetime
import time
#from weatherFunc import *
#from weatherBuffer import weatherBuffer
import re
import sys


time_stamp = None

try:	#we try because this might be the first time i buffer anything for this function
	infile = open("buffer_return_HTML_content_func.txt","r")	# open buffer file
	date = (infile.readline()).strip() 						# read date
	tid = int((infile.readline()).strip())					# time
	content_of_file = infile.read()							#if difference less then 6 hours 
	args = (re.findall("@@@(.*?)@@@",content_of_file,re.DOTALL)) # dette er argumentene
	results = (re.findall("###(.*?)###",content_of_file,re.DOTALL)) # dette er resultatet		
except:
	print "fail"

"""
README!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
dette er kun en fil for testing av smaa kodebiter... ikke en del av assignment 4
"""