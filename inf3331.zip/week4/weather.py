# -*- coding: utf-8 -*-
from weatherFunc import *
import re

"""
This is only to show you have to call functions
Not the actual assignment.
But it shows how your are intended to call them and print info
"""

if __name__ == '__main__':
	XmlListe = URL_to_XML_for_said_location("OSLO") #return_HTML_content(XmlListe[0])
	name, weather_summary, precipitation_value, wind_speed, temperature, time = tabular_info(return_HTML_content(XmlListe[0]))
	print name
	print weather_summary
	print precipitation_value
	print wind_speed
	print temperature
	print time

	weather_update_list = weather_update("Oslo", 18,55)
	for i in weather_update_list:
		print i