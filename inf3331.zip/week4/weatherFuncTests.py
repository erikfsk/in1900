# -*- coding: utf-8 -*-
import re
import os
import urllib2
from weatherFunc import *
from weatherBuffer import *
from testAvDummy import *
from subprocess import Popen, PIPE

def test_return_HTML_content():
	"""
	Here i open test_return_HTML_content.txt and saves it as exact
	i get content from return_HTML_content and 
	write it to a midlertidigTest.txt file
	i check if these two matches and assert it. 
	print success if successful
	"""
	exact = (open("test_return_HTML_content.txt","r")).read() # plz DO NOT touch this file!!! if u do the test will fail!
	content = return_HTML_content("http://www.islostarepeat.com/")
	testFile = open ("midlertidigTest.txt","w")
	testFile.write(content);testFile.close()
	computed = (open ("midlertidigTest.txt","r")).read()
	success = (str(exact) == str(computed))
	msg = "not as expected"
	os.remove("midlertidigTest.txt")
	assert success, msg
	print "test_return_HTML_content was successful!"

def test_URL_to_XML_for_said_location():
	"""
	if i call URL_to_XML_for_said_location("Hannestad") i should get back:
	a list which has len() 1 and has 
	"http://www.yr.no/place/Norway/Østfold/Sarpsborg/Hannestad/forecast.xml"
	as element 0. save these two as a new list. 
	computed and make a computed list. hopefully it looks like the expected
	list that we made.
	
	check if these two matches and assert it. 
	print success if successful
	"""
	exact = ["http://www.yr.no/place/Norway/Østfold/Sarpsborg/Hannestad/forecast.xml",1]
	return_value = URL_to_XML_for_said_location("Hannestad")
	computed = [return_value[0],len(return_value)]
	success = exact == computed
	msg = "not as expected"
	assert success,msg
	print "test_URL_to_XML_for_said_location was successful!"

def test_tabular_info():
	"""
	get back tabular_info(return_HTML_content("http://www.yr.no/place/Norway/Østfold/Sarpsborg/Hannestad/forecast.xml"))
	this returns many lists. I only check the temperature list in this test. (because thats what the assignment said)
	...dont mind the other lists...
	check that all values in temperature is between -50 and 50.
	if they are not, computed will be set to False
	exact is the expected value for computed. which is True
	i check if these two matches and assert it. 
	print success if successful
	"""
	exact = True
	computed = True

	name, weather_summary, precipitation_value, wind_speed, temperature, time = tabular_info(return_HTML_content("http://www.yr.no/place/Norway/Østfold/Sarpsborg/Hannestad/forecast.xml"))
	for i in temperature:
		i = int(i)
		if (i< -50 or i>50):
			computed = False

	success = exact == computed
	msg = "not as expected"
	assert success,msg
	print "test_tabular_info was successful!"

def test_weather_update():
	"""
	this is almost like the tabular info test... plz look at documentation there.
	difference is that this only evaluates one temp at the next 13:00
	and calls weather_update not tabular_info
	print success if successful
	"""
	exact = True
	computed = True
	info = (weather_update("Hannestad", 13, 0))[1]
	temp = int(((re.findall(".*temp\: (.{0,3}).*deg",info,re.IGNORECASE))[0]).strip())
	if (temp< -50 or temp>50):
			computed = False
	
	success = exact == computed
	msg = "not as expected"
	assert success,msg
	print "test_weather_update was successful!"

def test_weather_buffer1():
	"""
	use popen to get output from testAvDummy.py
	that file runs the dummy twice.
	the output should be (if it buffer the first result correctly):
	['calc', '4', '4', '']

	and (if it does not buffer the result correctly (or simply dont buffer at all)):
	['calc', '4', 'calc', '4', ''] 

	as always exact is the expected result and cumputed is the computed result.
	check if these two matches and assert it. 
	print success if successful
	"""
	output = Popen(["python", "testAvDummy.py"], stdout=PIPE).communicate()[0]
	output = output.split("\n")
	success = ['calc', '4', '4', ''] == output
	msg = "not as expected"
	os.remove("buffer_test_dummy_function.txt")
	assert success,msg
	print "test_weather_buffer1 was successful!"

def test_weather_buffer2():
	"""
	ok so this might be tricky, but i believe in u :)
	just follow the "#" comments
	"""
	for i in range(0,2,1):
		outfile = open("buffer_test_dummy_function.txt","w") 	# 
		date = time.strftime("%x"); 							#
		outfile.write(date+"\n")								#
		if (i == 0):											#if first test
			outfile.write(str(int(time.strftime("%H"))-7)+"\n")	#	write hour minus 7. range from -7 to 17							
		else:													#if second test
			outfile.write("23\n")								#	write 23
		outfile.close()											#

		test = weatherBuffer(test_dummy_function,24)			#creat buffer with time stamp 24
		infile = open("buffer_test_dummy_function.txt","r")		#
		date = (infile.readline()).strip()						#
		tid = int((infile.readline()).strip())					#
		if (i == 0):											#if first test
			success = (tid == 24)								#tid should now have been changed to 24
		else:													#if second test
			success = (tid == 23)								#tid should still be 23
		msg = "time stamp change failed (test %.f/2)" % (i+1)
		os.remove("buffer_test_dummy_function.txt")				# remove buffer file
		assert success,msg										
		print "test_weather_buffer2 was successful! (test %.f/2)" % (i+1)

if __name__ == '__main__':
	test_return_HTML_content()
	test_URL_to_XML_for_said_location()
	test_tabular_info()
	test_weather_update()
	test_weather_buffer1()
	test_weather_buffer2()

	"""
	run all tests and hope for the best :)

	output (if successful (should take less time then 10 seconds)):
	test_return_HTML_content was successful!
	test_URL_to_XML_for_said_location was successful!
	test_tabular_info was successful!
	test_weather_update was successful!
	test_weather_buffer1 was successful!
	test_weather_buffer2 was successful! (test 1/2)
	test_weather_buffer2 was successful! (test 2/2)
	"""