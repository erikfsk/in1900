"""
previous try of a buffer class...
"""
import urllib2
import time
import re



class weatherBuffer(object):
	"""docstring for weatherBuffer
	ehh hva kan en si? 
	sorry men her er det mye rar kode...
	"""
	def __init__(self, function, time_stamp = None):
		self.function = function 	# the function which we will buffer
		self.buffer = {}			# the dict for buffer result
		self.strFunction = (re.findall("\<function (.*) at.*\>",str(function),re.IGNORECASE))[0] #string that contains the name of the function
		try:	#we try because this might be the first time i buffer anything for this function
			infile = open("buffer_%s.txt" % self.strFunction,"r") 	# open buffer file
			date = (infile.readline()).strip() 						# read date
			tid = int((infile.readline()).strip())					# time
			if (date == time.strftime("%x")):						#if date equals todays date
				if (time_stamp != None):							#if time stamp, now is time stamp
					now = time_stamp								#
				else:												#else now is the actual now
					now = time.strftime("%H")						#
				if (int(now)-tid) < 6:								#if difference less then 6 hours 
					while(True):									#start to fill buffer
						line1 = (re.findall(".*",infile.readline(),re.IGNORECASE))[0] # dette er argumentet 
						line2 = (re.findall("#(.*?)#",infile.readline(),re.IGNORECASE)) # dette er resultatet
						if (line1 == ""): #this kicks in at the end of the file
							break		
						if (len(line2)==1): # if the result is just one thing 
							self.buffer[line1] = line2[0]	# dont buffer a list
						else:	
							self.buffer[line1] = line2		#otherwise buffer a list
				else:
					infile.close()
					raise # if time is invalid go to except
			else:
				infile.close()
				raise # if date is invalid go to except
			infile.close()

		except:
			date = time.strftime("%x") # u have seen this before....
			if (time_stamp != None):
				tid = time_stamp
			else:
				tid = time.strftime("%H") # repeat of previous code

		self.outfile = open("buffer_%s.txt" % self.strFunction,"w") # write out buffer to file
		self.outfile.write(date+"\n") # date
		self.outfile.write(str(tid)+"\n") # time
		for arg in self.buffer: # write all info in buffer
			self.outfile.write(arg+"\n")
			if (type(self.buffer[arg]) == list or type(self.buffer[arg]) == tuple):
				for i in self.buffer[arg]:
					self.outfile.write("#"+i+"# ")
				self.outfile.write("\n")
			else:
				self.outfile.write("#"+self.buffer[arg]+"#"+"\n")
		self.outfile.close()

	def __call__(self, arg):
		self.outfile = open("buffer_%s.txt" % self.strFunction,"a") # if you call append new buffer result at the end of file
		if str(arg) in self.buffer:
			return self.buffer[str(arg)] # return buffered result
		retval = self.function(arg) # calculate the result
		self.buffer[str(arg)] = retval
		self.outfile.write(str(arg)+"\n") # arg in a seperate line
		if (type(retval) == list or type(retval) == tuple): # buffer the result
			print "yes"
			for i in retval:
				self.outfile.write("#"+i+"# ") # write a result in one line with #surrounding each element in the result#
			self.outfile.write("\n")
		else:
			self.outfile.write("#"+(str(retval))+"#"+"\n")
		return retval # return calculation

if __name__ == '__main__':
	#tester_tester = weatherBuffer(URL_to_XML_for_said_location)
	#print tester_tester("Bergen")
	None
	"""
	try running it twice. should be a big difference in the time it takes to compute
	"""