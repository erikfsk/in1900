# -*- coding: utf-8 -*-
from weatherBuffer import *
import urllib2
import re

# . ^ $ * + ? { } [ ] \ | ( )
# mulige tegn

def return_HTML_content_func(webpage):
	"""
	it does what the title says
	call the class object named return_HTML_content
	not this function, if u want to use the buffer
	"""
	try:
		feedback = urllib2.urlopen(webpage) 
		stringfeedback = feedback.read()
		return stringfeedback 
	except:
		print "proably a defekt webpage will not use this ",webpage # This is in case the link is defekt
		print "return_HTML_content error\n"							# you will se the print if a webpage is defekt
		return "None"												# other functions will recognize this and do nothing if None is pasted

def URL_to_XML_for_said_location(location):
	"""
	returns urls to a xml file for each place that matches 
	the given location on "http://fil.nrk.no/yr/viktigestader/noreg.txt"
	return type is a list with 0 to 100 elements. 
	"""
	Resultater = []
	webpage = "http://fil.nrk.no/yr/viktigestader/noreg.txt"
	try:
		NRKyr = return_HTML_content(webpage)
		if (len(Resultater) == 0):
			Resultater = re.findall("\http://www.yr.no/place/.*?/.*?/.*?/%s.*?/forecast.xm\l" % location,NRKyr,re.IGNORECASE)#try stadnamn first
		if (len(Resultater) == 0):
			Resultater = re.findall("\http://www.yr.no/place/.*?/.*?/%s.*?/.*?/forecast.xm\l" % location,NRKyr,re.IGNORECASE)#try kommune second
		if (len(Resultater) == 0):
			Resultater = re.findall("\http://www.yr.no/place/.*?/%s.*?/.*?/.*?/forecast.xm\l" % location,NRKyr,re.IGNORECASE)#try fylke third
		if (len(Resultater) > 100): 	
			Resultater = Resultater[0:100]
		Resultater = slett_like_elementer(Resultater) 
		return Resultater 
	except:
		print "URL_to_XML_for_said_location error\n"

def slett_like_elementer(liste):
	"""
	gjett hva denne gjor??
	"""
	liste.sort()
	return_liste = []
	for i in liste:
		if not (i in return_liste):
			return_liste.append(i)
	return return_liste

def tabular_info(webpage):
	"""
	this function returns list with different info.
	normaly like this:
	return name, weather_summary, precipitation_value,
			wind_speed, temperature, tid


	might be like this:
	return "None","None","None",
			"None","None","None"

	if the webpage argument is given as "None".
	This will happen if the return_HTML_content gets a defekt link
	"""
	if (webpage != "None"):
		name = re.findall("\<location *name=\"(.*)\"\>",webpage,re.IGNORECASE) #Perfekt
		#<location name="Madland">

		weather_summary = re.findall("\<symbol.*name=\"(.*?)\".*var=\".*\".*\>",webpage,re.IGNORECASE) #Perfekt
		#<symbol number="4" numberEx="4" name="Cloudy" var="04"/>
		#<symbol number="3" name="Partly cloudy" time="2015-09-25T12:00:00Z" /> ikke match dette!

		precipitation_value = re.findall("\<precipitation value=\"(.*?)\".*\>",webpage,re.IGNORECASE) #Perfekt
		#<precipitation value="0" minvalue="0" maxvalue="0.6"/>

		wind_speed = re.findall("\<windSpeed mps=\"(.*?)\" name=\".{0,15}\" /\>",webpage,re.IGNORECASE) #Perfekt
		#<windSpeed mps="3.8" name="Gentle breeze" />
		#<windSpeed mps="5.0" name="Gentle breeze" time="2015-09-25T17:00:00Z"/> ikke match dette!

		temperature = re.findall("\<temperature.*value=\"(.{0,5})\".{0,3}\>",webpage,re.IGNORECASE)
		#<temperature unit="celsius" value="9"/>
		#<temperature unit="celsius" value="11.6" time="2015-09-25T17:00:00Z"/> ikke match dette

		tid = re.findall("\<time.*from=\".{0,11}(.{0,2}).{0,6}\".*to=\".{0,11}(.{0,2}).{0,6}\".*period.*\>",webpage,re.IGNORECASE) #Perfekt
		#<time from="2015-09-25T20:00:00" to="2015-09-26T00:00:00" period="3">

		return name, weather_summary, precipitation_value, wind_speed, temperature, tid
	return "None","None","None","None","None","None"

def weather_update(place,hour,minutt):
	"""
	returns a list with weather_updates
	the list element 0 is date and time
	every other element is a summary for a given place.
	example:
	['30.09.15 7:00','Oslo :  Fog , rain: 0  mm, wind: 0.7  mps, temp: 6  deg C']
	"""
	import time
	import datetime

	weather_update_list = []

	if (minutt > int(time.strftime("%M"))):
		er_idag_gyldig = 0 #JA
		print minutt
		print int(time.strftime("%M"))
	else:
		er_idag_gyldig = 1 #NEI
	#get time and date
	next_hour = int(time.strftime("%H")) + er_idag_gyldig
	if (hour < next_hour):
		day = re.findall(".{2,2}.{2,2}-.{2,2}-(.{2,2})",str(datetime.date.today() + datetime.timedelta(days=1)),re.IGNORECASE)
		month = re.findall(".{2,2}.{2,2}-(.{2,2})-.{2,2}",str(datetime.date.today() + datetime.timedelta(days=1)),re.IGNORECASE)
		year = re.findall(".{2,2}(.{2,2})-.{2,2}-.{2,2}",str(datetime.date.today() + datetime.timedelta(days=1)),re.IGNORECASE)
		weather_update_list.append("%s.%s.%s %s:00" % (day[0],month[0],year[0],hour))
	else:
		day = re.findall(".{2,2}.{2,2}-.{2,2}-(.{2,2})",str(datetime.date.today()),re.IGNORECASE)
		month = re.findall(".{2,2}.{2,2}-(.{2,2})-.{2,2}",str(datetime.date.today()),re.IGNORECASE)
		year = re.findall(".{2,2}(.{2,2})-.{2,2}-.{2,2}",str(datetime.date.today()),re.IGNORECASE)
		weather_update_list.append("%s.%s.%s %s:00" % (day[0],month[0],year[0],hour))
	#10.09.15 13:00

	if (er_idag_gyldig == 1): # just to retrieve the right day info
		er_idag_gyldig = 0
	else:
		er_idag_gyldig = 1
	"""
	this if and else is just to make
	the date today or tomorrow
	and format it like the assignment example
	"""

	counter = 0
	xml_linker_til_place = URL_to_XML_for_said_location(place)
	for i in xml_linker_til_place:
		name, weather_summary, precipitation_value, wind_speed, temperature, time = tabular_info(return_HTML_content(i))
		if (name != "None"):
			for i in range(0,5,1):
				if ((hour+er_idag_gyldig) > int(time[i][0])):
					if((hour+er_idag_gyldig) <= int(time[i][1])):
						counter = i
						break
			weather_update_list.append("%s :  %s , rain: %s  mm, wind: %s  mps, temp: %s  deg C" % (name[0],weather_summary[counter],precipitation_value[counter],wind_speed[counter],temperature[counter]))
	return weather_update_list

return_HTML_content = weatherBuffer(return_HTML_content_func)