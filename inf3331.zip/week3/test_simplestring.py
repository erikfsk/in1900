import simplestring

# Monkey patch raw_input for testing purposes, so
# that there is no user-interaction required
def mock_raw_input():
    return 'Eat fish to stay healthy!'
simplestring.raw_input = mock_raw_input

def test_simplestring(capsys):
    # Test the getString method
    s = simplestring.SimpleString()
    s.getString()

    # Check printString()
    capsys.readouterr()  # Flush leftover stdout
    s.printString()
    out, err = capsys.readouterr()
    assert out.strip() == "EAT FISH TO STAY HEALTHY!"
