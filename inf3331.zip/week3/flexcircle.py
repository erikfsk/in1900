#!/usr/bin/python

from math import pi,sqrt

class FlexCircle(object):
	"""Class for calculation of a circles perimeter and area"""
	def __init__(self,radius):
		if (radius < 0):
			print "Error, sry value cant be negative"
		else:	
			self.radius = radius
			self.area = pi*radius*radius
			self.perimeter = 2*pi*radius

	def set_area(self,value):
		if (value < 0):
			print "Error, sry value cant be negative"
		else:
			self._area = value
			self._radius = sqrt(float(value)/pi)
			self._perimeter = 2*(sqrt(float(value)/pi))

	def set_radius(self,value):
		if (value < 0):
			print "Error, sry value cant be negative"
		else:
			self._radius = value
			self._area = pi*value*value
			self._perimeter = 2*pi*value

	def set_perimeter(self,value):
		if (value < 0):
			print "Error, sry value cant be negative"
		else:
			self._area = pi*(float(value)/(2*pi))*(float(value)/(2*pi))
			self._radius = float(value)/(2*pi)
			self._perimeter = value
			

	def get_area(self):
		return self._area

	def get_radius(self):
		return self._radius

	def get_perimeter(self):
		return self._perimeter

	area = property(get_area,set_area)
	radius = property(get_radius,set_radius)
	perimeter = property(get_perimeter,set_perimeter)


if __name__ == '__main__':
	c = FlexCircle(radius=2)
	print c.area		# print area of circle with radius 2
	c.perimeter = 1.5 	# set perimeter of circle to 1.5
	print c.radius 		# print radius for circle with a perimeter of 1.5
	c.area = 0.6 		# set area of circle to 0.6
	print c.perimeter	# print perimeter of circle with 0.6 area