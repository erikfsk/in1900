from math import pi
from circle import Circle

def test_circle():
    r = 11.2
    c = Circle(radius=r)
    assert abs(c.area() - pi*r**2) < 1e-10
    assert abs(c.perimeter() - 2*pi*r) < 1e-10
