from math import pi
from flexcircle import FlexCircle

def test_flexcircle():
    r = 15.8

    c = FlexCircle(radius=r)
    assert c.radius == 15.8

    assert abs(c.area - pi*r**2) < 1e-10

    # set perimeter of circle to 1.5
    c.perimeter = 1.5
    assert c.perimeter == 1.5
    assert abs(c.radius - 1.5/2/pi) < 1e-10
    assert abs(c.area - pi*c.radius**2) < 1e-10

    # set area of circle to 0.6
    c.area = 0.6
    assert c.area == 0.6
    assert abs(c.radius - (0.6/pi)**0.5) < 1e-10
