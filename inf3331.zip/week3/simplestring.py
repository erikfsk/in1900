

class SimpleString(object):
	def __init__(self):
		self.text = ""

	def getString(self):
		print "Enter String Value: "
		self.text = raw_input().upper()

	def printString(self):
		print self.text



if __name__ == '__main__':
	s = SimpleString()
	s.getString()
	s.printString()