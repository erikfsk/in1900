#!/usr/bin/python

infile = open("data.log","r")
myDict = {}

def main():
	for line in infile:
		words = line.split()
		if (len(words) > 0):
			if ("Running" in line):
				keyword = words[2]
				if (False ==(keyword in myDict.keys())):
					myDict[keyword] = []
			if ("Name:" in line):
				(myDict[keyword]).append(float(words[3]))

	for keys in myDict:
		print "Test name: ",keys
		print "CPU time: %7.1f s (min)" % (min(myDict[keys]))
		print "%17.1f s (avg)" % (sum(myDict[keys])/len(myDict[keys]))
		print "%17.1f s (max)\n" % (max(myDict[keys]))

if __name__ == '__main__':
	main()