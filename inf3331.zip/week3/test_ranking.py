
def test_ranking(capsys):

    # import the module
    # this will run the ranking code
    import ranking

    # catch the stdout
    out, err = capsys.readouterr()  # Flush leftover stdout
    out = out.strip().split("\n")

    # Test the timings for 2 benchmarks: Heart2 and Vessell_bottom
    for i in range(len(out)):
        if "Heart2" in out[i]:
            assert "min" in out[i+1]
            assert "160.3" in out[i+1]

            assert "avg" in out[i+2]
            assert "191.5" in out[i+2]

            assert "max" in out[i+3]
            assert "207.7" in out[i+3]

        if "Vessell_bottom" in out[i]:
            assert "min" in out[i+1]
            assert "565.4" in out[i+1]

            assert "avg" in out[i+2]
            assert "587.3" in out[i+2]

            assert "max" in out[i+3]
            assert "607.4" in out[i+3]
