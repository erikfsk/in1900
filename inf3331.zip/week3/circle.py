#!/usr/bin/python

from math import pi

class Circle(object):
	"""Class for calculation of a circles perimeter and area"""
	def __init__(self,radius):
		self.radius = radius
	def area(self):
		return pi*self.radius*self.radius
	def perimeter(self):
		return 2*pi*self.radius



if __name__ == '__main__':
	c = Circle(radius = 10)
	print "Area = {0}, Perimeter: {1}".format(c.area(), c.perimeter())
	