if [ "$1" == "-h" ]; then
	echo "Arg 1 should be a directory and arg 2 should be the minimum size in kilobytes that u want your files to be."
	exit 0
fi

echo 'size in:', $2
files=$(find $1 -size +$2k)
echo $files
gzip $files