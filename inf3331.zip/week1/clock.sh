trap "echo Bye Bye; exit 0" SIGINT control_c

while true;
do
	echo | date
done