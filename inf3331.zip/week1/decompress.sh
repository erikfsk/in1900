if [ "$1" == "-h" ]; then
	echo "Arg 1 should be a directory where the gz files which u want to decompress is located"
	exit 0
fi

files=$(find $1 -name "*.gz")
gzip -d $files